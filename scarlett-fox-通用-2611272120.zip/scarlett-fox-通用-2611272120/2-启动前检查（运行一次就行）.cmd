@echo off
>> "%~dp0_run.log" echo [%date% %time%] START %~nx0
echo  ============================================================
echo   *** �� 2 �� / �� 5 �� ***
echo   ������Ŀ�ģ������峡��ɾ�����л��棨������Ԥ�Ȼ��棩
echo   ���ã���ֹ�����汾������ɽṹ�Գ�ͻ���ϱ�/����/�ڿ飩
echo   ע�⣺�峡����Ҫ�����ܵ� 3 ��Ԥ�ȣ��ճ�����ֱ���õ� 5 ��
echo   ��10 ����Զ��������� T �������룩
echo  ============================================================
choice /c T /n /t 10 /d T >nul
rem ============================================================
rem  Step 1 - pre-launch check + full cache wipe (runs every time)
rem  Deletes ALL caches, including our own, to rule out any
rem  structural conflict with other forks. Prewarm again after.
rem ============================================================
setlocal EnableExtensions EnableDelayedExpansion
title Pre-launch check

echo  ============================================
echo   PRE-LAUNCH CHECK (all steps re-done always)
echo  ============================================

rem ---- step 1: no leftover game processes ----
echo  [1/5] checking leftover victory processes ...
tasklist /FI "IMAGENAME eq victory.exe" 2>nul | find /I "victory.exe" >nul
if %errorlevel%==0 (
  echo        FOUND a running victory.exe - close it first, then run again.
  rem anti-keystroke-leak guard
  timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - no leftover processes.

rem ---- step 2: exe integrity ----
echo  [2/5] checking victory.exe SHA256 ...
set "H="
for /f "skip=1 tokens=*" %%h in ('certutil -hashfile "%~dp0victory.exe" SHA256 2^>nul') do if not defined H set "H=%%h"
set "H=%H: =%"
if /I not "%H%"=="3793dd8ab7cca14602d4eae6045e7137dc6367dc126d0e9e63eec134124d2c65" (
  echo        MISMATCH! victory.exe is not the verified build.
  echo        got: %H%
  echo        Do NOT mix exes from other forks. Aborting.
  rem anti-keystroke-leak guard
  timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - verified build.

rem ---- step 3: cache isolation (ALL caches deleted, on purpose) ----
echo  [3/5] checking caches (ALL caches are deleted, by design) ...
if exist "%LOCALAPPDATA%\victory" (
  echo        FOUND shared cache %LOCALAPPDATA%\victory - another fork used it.
  echo        Its stale shaders cause PURPLE TREES and FLICKERING models.
  echo        Deleting it now ^(it rebuilds automatically^) ...
  rd /s /q "%LOCALAPPDATA%\victory"
  echo        deleted.
)
if exist "%LOCALAPPDATA%\VIctory" (
  echo        FOUND %LOCALAPPDATA%\VIctory from the NVIDIA fork - deleting ...
  rd /s /q "%LOCALAPPDATA%\VIctory"
  echo        deleted.
)
if exist "%LOCALAPPDATA%\victory-scarlett-fox" (
  echo        FOUND our warm cache - deleting too ^(full clean start, no structural conflict^) ...
  rd /s /q "%LOCALAPPDATA%\victory-scarlett-fox"
  echo        deleted.
)
if not exist "%LOCALAPPDATA%\victory" if not exist "%LOCALAPPDATA%\VIctory" if not exist "%LOCALAPPDATA%\victory-scarlett-fox" echo        ok - no cache on disk at all (clean start).

rem ---- step 4: game folder ----
echo  [4/5] checking game folder ...
if exist "%~dp0_game-path.cmd" call "%~dp0_game-path.cmd"
if not defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=C:\GTAVI\GTA6.Xbox.v1.0.2.1"
rem accept hand-edited paths: strip quotes and a trailing backslash
if defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:"=%"
if "%VICTORY_GAME_DIR:~-1%"=="\" set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:~0,-1%"
if not exist "%VICTORY_GAME_DIR%\game_scarlett_master.exe" (
  echo        game_scarlett_master.exe NOT FOUND in %VICTORY_GAME_DIR%
  echo        Run ������Ϸ·��.cmd to pick the right folder, then re-run this check.
  rem anti-keystroke-leak guard
  timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - %VICTORY_GAME_DIR%

rem ---- step 5: prewarm state ----
echo  [5/5] checking prewarm state ...
if exist "%LOCALAPPDATA%\victory-scarlett-fox" (
  echo        warm cache present - you can start with 5-��������.
) else (
  echo        caches were cleared - run 3-��һ������ to prewarm ^(about 21 minutes^),
  echo        then 4-Ԥ����ɫ��, then 5-�������� for daily play.
)
rem ---- backup the player's own save ----
echo  [backup] your own save ...
set "BK=%~dp0my-save-backup"
set "DATA=%LOCALAPPDATA%\victory-scarlett-data"
set "TID="
for /d %%d in ("%DATA%\*") do if /i not "%%~nxd"=="saves" if /i not "%%~nxd"=="saves.backup" set "TID=%%~nxd"
if not defined TID set "TID=7952987A"
set "SAVEDIR=%DATA%\%TID%\saves"
if exist "%SAVEDIR%" (
  echo        found your save: %SAVEDIR%
  set /p BKQ=       back it up? restored automatically at the end of 4-Ԥ����ɫ�� ^(Y/n^):
  if /I not "!BKQ!"=="n" (
    if exist "%BK%" rd /s /q "%BK%"
    xcopy "%SAVEDIR%" "%BK%\saves" /E /I /Y /Q >nul
    echo        backed up to %BK%\saves
  ) else (
    echo        skipped - your save will be REPLACED by the free-roam one in 3.
  )
) else (
  echo        no save on disk - nothing to back up.
)

>> "%~dp0_run.log" echo [%date% %time%] END (script reached the end)
echo  ============================================
echo   ALL CHECKS PASSED
echo   after a full clean: 3 -^> 4 -^> 5
echo   daily play: run 5-�������� only
echo  ============================================
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
pause
exit /b 0
