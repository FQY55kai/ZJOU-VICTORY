﻿param([string]$Path = "")
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms | Out-Null

$chosen = $Path
if (-not $chosen) {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "选择包含 game_scarlett_master.exe 的游戏文件夹"
    $dlg.ShowNewFolderButton = $false
    $dlg.RootFolder = [System.Environment+SpecialFolder]::MyComputer
    $r = $dlg.ShowDialog()
    if ($r -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }
    $chosen = $dlg.SelectedPath
}
if (-not $chosen) { exit 1 }
$out = Join-Path $PSScriptRoot '_picked-path.txt'
[System.IO.File]::WriteAllText($out, $chosen, [System.Text.Encoding]::GetEncoding(936))
exit 0
