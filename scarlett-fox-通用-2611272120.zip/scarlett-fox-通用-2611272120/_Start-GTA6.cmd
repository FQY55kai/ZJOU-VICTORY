@echo off
rem ============================================================
rem  GTA VI (Xbox) -> PC - victory-scarlett (scarlett-fox branch)
rem  Multi-VRAM edition: 8GB / 12GB / 16GB+ profiles
rem  Cache isolation: dedicated cache dir, never shared with other forks
rem  Build: cargo build --release --locked --bin victory
rem ============================================================
setlocal EnableExtensions

rem ---- EDIT THIS: your game folder ----
if exist "%~dp0_game-path.cmd" call "%~dp0_game-path.cmd"
if not defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=C:\GTAVI\GTA6.Xbox.v1.0.2.1"
rem accept hand-edited paths: strip quotes and a trailing backslash
if defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:"=%"
if "%VICTORY_GAME_DIR:~-1%"=="\" set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:~0,-1%"
set "VICTORY_EXE=%~dp0victory.exe"

rem ---- VRAM profile: AUTO / 8 / 12 / 16 (auto-detected when not set) ----
if not defined VICTORY_PROFILE (
  setlocal EnableDelayedExpansion
  set "VRAM=0"
  for /f "tokens=1" %%m in ('nvidia-smi --query-gpu=memory.total --format=csv,noheader 2^>nul') do set /a VRAM=%%m 2>nul
  if !VRAM! LEQ 0 for /f "tokens=1" %%m in ('"%ProgramFiles%\NVIDIA Corporation\NVSMI\nvidia-smi.exe" --query-gpu=memory.total --format=csv,noheader 2^>nul') do set /a VRAM=%%m 2>nul
  if !VRAM! LEQ 0 (endlocal & set "VICTORY_PROFILE=12") else if !VRAM! LEQ 9216 (endlocal & set "VICTORY_PROFILE=8") else if !VRAM! LEQ 14336 (endlocal & set "VICTORY_PROFILE=12") else (endlocal & set "VICTORY_PROFILE=16")
)

rem ---- cache and save isolation (DO NOT share with other forks) ----
set "VICTORY_CACHE_DIR=%LOCALAPPDATA%\victory-scarlett-fox"
if not defined VICTORY_DATA_DIR set "VICTORY_DATA_DIR=%LOCALAPPDATA%\victory-scarlett-data"

rem ---- picture fixes (upstream launcher defaults; fixes violet vegetation and purple patches) ----
set VICTORY_PROBE_RAYS=1
set VICTORY_PLANE_NOW=1
rem ---- crash prevention (DO NOT change) ----
set VICTORY_TEXTURE_MIP_DROP=1
set VICTORY_FRAME_INTERVAL_MS=33.3
set VICTORY_CARD_BUFFERS_MIN_KB=64
set VICTORY_PIPELINE_BOOK=1
set VICTORY_LOG=info
set VICTORY_MAX_PRELUDES=32
set VICTORY_LEVELS_ON_DEMAND=0
set VICTORY_WAIT_RESIDENT=0
set VICTORY_REFRESH_ONCE=1
set VICTORY_CARD_REHASH_RUNS=1
set VICTORY_WIDE_MERGE=1
set VICTORY_MIRROR_FAST=1
set VICTORY_PIPELINE_WAIT_MS=20
set VICTORY_ASYNC_SUBMIT=1
set VICTORY_INDIRECT_WINDOW=1
set VICTORY_TEXTURE_NO_WAIT=1
set VICTORY_COPY_PLAIN=1
set VICTORY_WIDE_TEXTURES=1
set VICTORY_INDIRECT_GATHER=1
set VICTORY_LATE_WAIT_LISTS=1024
set VICTORY_CARD_FILLS_BATCH=0
set VICTORY_GATHER_DISPATCH=0
set VICTORY_RELAY=2
set VICTORY_WIDE_BACK=1
set VICTORY_RELAY_COPY=1
set VICTORY_CARD_STEPS=2
set VICTORY_INDIRECT_BATCH=2
set VICTORY_MAP_THREADS=1
set VICTORY_CARD_AWAKE=0
set VICTORY_SHOW_AFTER=1
set VICTORY_JOIN_PARTS=8
set VICTORY_UPLOAD_AHEAD=1
set VICTORY_POOL_DISCARD=1
set VICTORY_FILL_TITLE=1
set VICTORY_PARTIAL_DELTA=1
set VICTORY_BAKE_DELTA=1
set VICTORY_MAP_LOCK_FINE=1
set VICTORY_POOL_CAP=1
set VICTORY_TABLE_MEMO=1
set VICTORY_LIST_ALIAS_EXACT=1
set VICTORY_LIST_HOLD=1
set VICTORY_EARLY_TEXTURES_MS=40
set VICTORY_BAKE_TEXTURES_MS=10000
set VICTORY_HEAP_PASS_MAX=0
set VICTORY_HEAP_CHANGED_MAX=0
set VICTORY_LEAVE_OUT=02384a60fda6f2d0
set VICTORY_WC_NO_BACK=1
set VICTORY_WC_NO_BACK_MIN_KB=1024
set VICTORY_SYNC_IN_PLACE=1
set VICTORY_SPANS_QUICK=1
set VICTORY_SYNC_FINE=1
set VICTORY_HEAP_SYNC_FIRST=1
set VICTORY_HEAP_SYNC_AT_SUBMIT=1
set VICTORY_SOFT_VIEWS=copies
set VICTORY_SAMPLERS_MADE=1
set VICTORY_TABLE_NAMED_ONLY=1
set VICTORY_QUEUE_MARKS=1
set VICTORY_PORT_CONSTANTS=1
set VICTORY_EARLY_DEPTH=1
set VICTORY_AMBIENT=0.8
set VICTORY_AMBIENT_AIR=1.5

rem ---- per-VRAM budget ----
if "%VICTORY_PROFILE%"=="8" (
  set VICTORY_TEXTURE_BUDGET_MB=4096
  set VICTORY_TEXTURE_ROOM_PERCENT=80
  set VICTORY_CARD_BUFFERS_MB=512
  set VICTORY_CARD_WINDOWS_MB=256
  set VICTORY_DYNAMIC_SLOTS=262144
)
if "%VICTORY_PROFILE%"=="12" (
  set VICTORY_TEXTURE_BUDGET_MB=8192
  set VICTORY_TEXTURE_ROOM_PERCENT=85
  set VICTORY_CARD_BUFFERS_MB=1024
  set VICTORY_CARD_WINDOWS_MB=512
  set VICTORY_DYNAMIC_SLOTS=524288
)
if "%VICTORY_PROFILE%"=="16" (
  set VICTORY_TEXTURE_MIP_DROP=0
  set VICTORY_TEXTURE_BUDGET_MB=12288
  set VICTORY_TEXTURE_ROOM_PERCENT=90
  set VICTORY_CARD_BUFFERS_MB=2048
  set VICTORY_CARD_WINDOWS_MB=1024
  set VICTORY_DYNAMIC_SLOTS=524288
)

"%VICTORY_EXE%" run "%VICTORY_GAME_DIR%\game_scarlett_master.exe" --execute --console series-s
