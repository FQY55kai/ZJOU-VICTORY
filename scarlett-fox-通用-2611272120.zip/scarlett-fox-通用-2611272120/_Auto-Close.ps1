﻿param([int]$Minutes = 10)
# Closes the game after N minutes IF the game process is still the one we watched.
# Exits early when the game is already gone.
$start = Get-Date
while (((Get-Date) - $start).TotalMinutes -lt $Minutes) {
    if (-not (Get-Process -Name victory -ErrorAction SilentlyContinue)) { exit 0 }
    Start-Sleep -Seconds 10
}
Stop-Process -Name victory -Force -ErrorAction SilentlyContinue
