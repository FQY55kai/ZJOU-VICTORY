@echo off
>> "%~dp0_run.log" echo [%date% %time%] START %~nx0 & echo         (window opened)
echo  ============================================================
echo   *** �� 1 �� / �� 4 �� ***
echo    ������Ŀ�ģ�������л�������ɾ�����оɻ��棨Լ 1-2GB�����Զ��ؽ���
echo    ���ã���ֹ�����汾����������ľ�ϱߡ�ģ������
echo    ע�⣺���� deleted ��������������������رա�Լ 1 ����
echo   ��10 ����Զ��������� T �������룩
echo  ============================================================
choice /c T /n /t 10 /d T >nul
rem ============================================================
rem  Pre-launch check - RUN THIS EVERY TIME before starting
rem  No prompts, safe to run unattended. Every step re-done always.
rem  ASCII only. CRLF.
rem ============================================================
setlocal EnableExtensions
title Pre-launch check

echo  ============================================
echo   PRE-LAUNCH CHECK (all steps re-done always)
echo  ============================================

rem ---- step 1: no leftover game processes ----
echo  [1/5] checking leftover victory processes ...
tasklist /FI "IMAGENAME eq victory.exe" 2>nul | find /I "victory.exe" >nul
if %errorlevel%==0 (
  echo        FOUND a running victory.exe - it may hold another fork's
  echo        exe or cache. Close it first, then run this check again.
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - no leftover processes.

rem ---- step 2: exe integrity ----
echo  [2/5] checking victory.exe SHA256 ...
set "H="
for /f "skip=1 tokens=*" %%h in ('certutil -hashfile "%~dp0victory.exe" SHA256 2^>nul') do if not defined H set "H=%%h"
set "H=%H: =%"
if /I not "%H%"=="3793dd8ab7cca14602d4eae6045e7137dc6367dc126d0e9e63eec134124d2c65" (
  echo        MISMATCH! victory.exe is not the verified build.
  echo        got: %H%
  echo        Do NOT mix exes from other forks. Aborting.
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - verified build.

rem ---- step 3: cache isolation ----
echo  [3/5] checking caches (any cache found is deleted) ...
if exist "%LOCALAPPDATA%\victory" (
  echo        FOUND shared cache %LOCALAPPDATA%\victory - another fork used it.
  echo        Its stale shaders cause PURPLE TREES and FLICKERING models.
  echo        Deleting it now ^(it rebuilds automatically^) ...
  rd /s /q "%LOCALAPPDATA%\victory"
  echo        deleted.
)
if exist "%LOCALAPPDATA%\VIctory" (
  echo        FOUND %LOCALAPPDATA%\VIctory from the NVIDIA fork - deleting ...
  rd /s /q "%LOCALAPPDATA%\VIctory"
  echo        deleted.
)
if exist "%LOCALAPPDATA%\victory-scarlett-fox" (
  echo        FOUND dedicated cache %LOCALAPPDATA%\victory-scarlett-fox - deleting ...
  rd /s /q "%LOCALAPPDATA%\victory-scarlett-fox"
  echo        deleted.
)
if not exist "%LOCALAPPDATA%\victory" if not exist "%LOCALAPPDATA%\VIctory" if not exist "%LOCALAPPDATA%\victory-scarlett-fox" echo        ok - no cache on disk at all (clean start).

rem ---- step 4: game folder ----
echo  [4/5] checking game folder ...
if exist "%~dp0_game-path.cmd" call "%~dp0_game-path.cmd"
if not defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=C:\GTAVI\GTA6.Xbox.v1.0.2.1"
rem accept hand-edited paths: strip quotes and a trailing backslash
if defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:"=%"
if "%VICTORY_GAME_DIR:~-1%"=="\" set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:~0,-1%"
if not exist "%VICTORY_GAME_DIR%\game_scarlett_master.exe" (
  echo        game_scarlett_master.exe NOT FOUND in %VICTORY_GAME_DIR%
  echo        Edit the path in _Start-GTA6.cmd, then re-run this check.
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
  pause
  exit /b 1
)
echo        ok - %VICTORY_GAME_DIR%

rem ---- step 5: first-run shader prewarm state ----
echo  [5/5] checking prewarm state ...
if exist "%LOCALAPPDATA%\victory-scarlett-fox" (
  echo        dedicated cache present - prewarm already done, you can start.
) else (
  echo        cache was cleared above - next: run the file with number 2
  echo        ^(! first launch, about 21 minutes^), then use the file with number 4.
)
echo  ============================================
echo   ALL CHECKS PASSED - next: file 2 on first launch, file 4 afterwards.
echo  ============================================
>> "%~dp0_run.log" echo [%date% %time%] END (script reached the end)
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
pause
exit /b 0
