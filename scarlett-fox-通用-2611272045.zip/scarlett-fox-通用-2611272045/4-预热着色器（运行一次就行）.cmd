@echo off
>> "%~dp0_run.log" echo [%date% %time%] START %~nx0 & echo         (window opened)
echo  ============================================================
echo   *** �� 4 �� / �� 5 �� ***
echo    ������Ŀ�ģ�����ͼ��¼����Ԥ����ͼ�ι��ߣ�Ȼ��ɾ������ģʽ�浵
echo    ע�⣺���ڲ���������������رգ�������浵����������Ϊ
echo    ��ɫ������͹��߻����ȫ��������Լռ�����ӵ� 20 ����
echo   ��5 ����Զ�����������رձ����ڣ�
echo  ============================================================
timeout /t 5 /nobreak >nul
rem ============================================================
rem  STEP 3 - PREWARM + CLEAN OUT THE FREE-ROAM SAVE
rem  Builds host pipelines for everything the open-world sweep
rem  recorded (shaders + pipeline book), THEN deletes the save so
rem  the next launch starts a brand-new game.
rem  KEEPS the shader cache and the pipeline cache (that is the
rem  whole point: warm caches, fresh save).
rem  ASCII only inside. CRLF.
rem ============================================================
setlocal EnableExtensions
set "EXE=%~dp0victory.exe"
if exist "%~dp0_game-path.cmd" call "%~dp0_game-path.cmd"
if not defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=C:\GTAVI\GTA6.Xbox.v1.0.2.1"
rem accept hand-edited paths: strip quotes and a trailing backslash
if defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:"=%"
if "%VICTORY_GAME_DIR:~-1%"=="\" set "VICTORY_GAME_DIR=%VICTORY_GAME_DIR:~0,-1%"
set "GAME=%VICTORY_GAME_DIR%"
set "DATA=%LOCALAPPDATA%\victory-scarlett-data"
set "CACHE=%LOCALAPPDATA%\victory-scarlett-fox"
set "VICTORY_GAME_DIR=%GAME%"
set "VICTORY_DATA_DIR=%DATA%"
set "VICTORY_CACHE_DIR=%CACHE%"
set "VICTORY_PIPELINE_BOOK=1"

echo  ============================================================
echo    PREWARM - build every pipeline the sweep recorded
echo  ============================================================
echo  [1/3] warming pipelines from the book ...
"%EXE%" warm --used

echo  [2/3] deleting the free-roam save (caches are kept) ...
set "TID="
for /d %%d in ("%DATA%\*") do (
  if /i not "%%~nxd"=="saves" if /i not "%%~nxd"=="saves.backup" set "TID=%%~nxd"
)
if not defined TID set "TID=7952987A"
if exist "%DATA%\%TID%\saves" (
  rd /s /q "%DATA%\%TID%\saves"
  echo        save deleted - next launch starts a brand-new game.
) else (
  echo        no save on disk - already clean.
)
if exist "%DATA%\%TID%\saves.backup" rd /s /q "%DATA%\%TID%\saves.backup"
if exist "%DATA%\saves" rd /s /q "%DATA%\saves"
if exist "%DATA%\saves.backup" rd /s /q "%DATA%\saves.backup"
echo        shader cache kept:   %CACHE%\shaders
echo        pipeline cache kept: %CACHE%\pipelines

echo  [3/3] done. Use 5-�������� from now on.
>> "%~dp0_run.log" echo [%date% %time%] END (script reached the end)
rem anti-keystroke-leak guard
timeout /t 2 /nobreak >nul
pause
